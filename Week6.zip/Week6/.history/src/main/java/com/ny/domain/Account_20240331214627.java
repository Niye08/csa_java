package com.ny.domain;

import java.sql.Date;

public class Account {
    private String id;
    private String name;
    private int money;
    private Date createtime;
    private Date updatetime;

    // Getter for id
    public String getId() {
        return id;
    }

    // Setter for id
    public void setId(String id) {
        this.id = id;
    }

    // Getter for name
    public String getName() {
        return name;
    }

    // Setter for name
    public void setName(String name) {
        this.name = name;
    }

    // Getter for money
    public int getMoney() {
        return money;
    }

    // Setter for money
    public void setMoney(int money) {
        this.money = money;
    }

    // Getter for createtime
    public Date getCreatetime() {
        return createtime;
    }

    // Setter for createtime
    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    // Getter for updatetime
    public Date getUpdatetime() {
        return updatetime;
    }

    // Setter for updatetime
    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}