import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.session.SqlSession;

import com.ny.dao.AccountDao;

public class AccountService {
    private InputStream inputStream;
    private SqlSession sqlSession;
    private AccountDao accountDao;

    public AccountService() throws IOException {
        // InputStream inputStream =
    }
}