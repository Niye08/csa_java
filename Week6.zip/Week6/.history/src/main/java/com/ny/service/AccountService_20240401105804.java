package com.ny.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
//import com.ny.domain.Account;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.ny.dao.AccountDao;
import com.ny.domain.Account;

public class AccountService {
    private InputStream inputStream;
    private SqlSession sqlSession;
    private AccountDao accountDao;

    public AccountService() throws IOException {
        inputStream = Resources.getResourceAsStream("AccountMapper.xml");
        SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(inputStream);
        sqlSession = factory.openSession();
        accountDao = sqlSession.getMapper(AccountDao.class);
    }

    // 释放资源
    private void destroy() {
        try {
            sqlSession.commit();
            sqlSession.close();
        } catch (IOException e) {
            // TODO: handle exception
            e.printStackTrace();
        }
    }

    // 1查询所有记录
    List<Account> findAll() {
    };

    // 2通过id删除记录
    void deleteByPrimarkey(String id) {
    };

    // 3插入记录
    void insert(Account record) {
    };

    // 4通过id查找对象
    Account selectByPrimarykey(String id) {
    };

    // 5更新Account
    void updateByPrimarykey(Account record) {
    };

    // 6.转账功能，输入转出人id，转入人id，转账金额，实现转账
    void transfer(String remitterID, String remitted, int money) {

    }

}
