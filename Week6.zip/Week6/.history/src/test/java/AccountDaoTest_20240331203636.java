
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import com.ny.domain.Account;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class AccountDaoTest {
    public static void main(String[] args) throws IOException {
        // 加载mybatis的核心配置文件，获取SQLsessionFactort
        String resource = "src/main/resources/Mybatis-config.xml";
        var res = AccountDaoTest.class.getResource(resource);
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();
        List<Account> accounts = sqlSession.selectList("test.selectAll");
        System.out.println(accounts);
        sqlSession.close();
    }
}