import java.io.IOException;
import com.ny.domain.Account;
import com.ny.service.AccountService;

public class AccountServiceTest {
    private AccountService accountService;

    public void init() throws IOException {
        accountService = new AccountService();
    }

    // 1查询所有记录
    public void tetsFindAll() {
    };

    // 2通过id删除记录
    public void testdeleteByPrimarkey(String id) {
    };

    // 3插入记录
    public void tetsinsert(Account record) {
    };

    // 4通过id查找对象
    public void testselectByPrimarykey(String id) {
    };

    // 5更新Account
    public void testupdateByPrimarykey(Account record) {
    };

    // 6.转账功能，输入转出人id，转入人id，转账金额，实现转账
    public void testtransfer(String remitterID, String remitted, int money) {

    }

    public static void main(String[] args) {
        try {
            AccountServiceTest test = new AccountServiceTest();
            test.testFindAll();
            // 执行其他测试方法
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
