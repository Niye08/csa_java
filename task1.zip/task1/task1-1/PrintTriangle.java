
import java.util.Scanner;

public class PrintTriangle {
    public static void showTriangle(int n) {
        // n为行数
        for (int i = 1; i <= n; i++) {
            for (int k = n - 1; k >= i; k--) {
                System.out.print(" ");
            }
            for (int j = 0; j < i - 1; j++) {
                System.out.print("*");
            }
            System.out.print("*");
            for (int j = 0; j < i - 1; j++) {
                System.out.print("*");
            }
            for (int k = n - 1; k >= i; k--) {
                System.out.print(" ");
            }
            System.out.print("\n");
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入你想要的行数：");
        int n = scanner.nextInt();
        showTriangle(n);
    }
}