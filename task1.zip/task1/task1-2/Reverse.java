import java.util.Scanner;

public class Reverse {
    public static void reverseSUM(String s) {
        // 用数组完成 转换工具如下
        char[] chars = s.toCharArray(); // 字符串转化为字符数组 String s1 =
        // String.valueOf(chars);//字符数组转化为字符串
        // 在此打印结果
        System.out.println("您输入的正整数的位数是：" + chars.length);
        System.out.print("您输入的正整数的逆序是：");
        for (int i = chars.length - 1; i >= 0; i--) {
            System.out.print(chars[i]);
        }
    }

    public static void main(String[] args) {
        System.out.print("请输入一个正整数：");
        Scanner scanner = new Scanner(System.in);
        String number = scanner.nextLine();
        reverseSUM(number);
    }
}