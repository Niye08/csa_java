import java.util.Scanner;

public class JudgeHuiwen {
    public static boolean Judgement(String s) {
        char[] chars = s.toCharArray(); // 字符串转化为字符数组
        String s1 = "";
        for (int i = s.length() - 1; i >= 0; i--) {
            s1 += chars[i];
        }
        return s.equals(s1);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入需要判断的数字：");
        String number = scanner.nextLine();
        if (Judgement(number)) {
            System.out.println("是回文数");
        } else {
            System.out.println("不是回文数");
        }
        scanner.close();
    }
}