public class JudgeShuixianhua {
    public static boolean Judgement(int s) {
        int sum = 0;
        int temp = s;
        while (temp != 0) {
            int digit = temp % 10;
            sum += cubeOfNumber(digit);
            temp = temp / 10;
        }
        return sum == s;
    }

    public static int cubeOfNumber(int number) {
        return number * number * number;
    }

    public static void main(String[] args) {
        for (int j = 100; j <= 999; j++) {
            if (Judgement(j)) {
                System.out.print(j + " ");
            }
        }
    }
}