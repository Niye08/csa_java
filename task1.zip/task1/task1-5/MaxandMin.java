public class MaxandMin {
    public static void main(String[] args) {
        int[] number = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        arraysDemo(number);
    }

    public static void arraysDemo(int[] number) { // 操作

        int min = number[0];
        int max = number[0];
        for (int i = 0; i < 10; i++) {
            if (number[i] < min) {
                min = number[i];
            }
            if (number[i] > max) {
                max = number[i];
            }
        }
        System.out.println("这个数组的最大值是：" + max + "最小值是：" + min + ",它们的和是：" + (max + min));

    }
}