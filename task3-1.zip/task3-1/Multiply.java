public class Multiply implements Compute {
    public int compute(int n, int m) {
        return n * m;
    }
}