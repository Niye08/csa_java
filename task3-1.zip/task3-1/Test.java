public class Test {
    public static void main(String[] args) {
        Compute add = new Add();
        Compute subtract = new Subtract();
        Compute multiply = new Multiply();
        Compute divide = new Divide();
        UseCompute useCompute = new UseCompute();
        useCompute.useCom(add, 4, 2);
        useCompute.useCom(subtract, 4, 2);
        useCompute.useCom(multiply, 4, 2);
        useCompute.useCom(divide, 4, 2);
    }
}