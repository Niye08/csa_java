public interface Compute {
    int compute(int n, int m);
}