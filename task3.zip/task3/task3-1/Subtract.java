public class Subtract implements Compute {
    public int compute(int n, int m) {
        return n - m;
    }
}