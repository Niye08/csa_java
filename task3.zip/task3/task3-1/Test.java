import java.util.ArrayList;

public class Test {
    public static void main(String[] args) {
        Compute add = new Add();
        Compute subtract = new Subtract();
        Compute multiply = new Multiply();
        Compute divide = new Divide();
        // UseCompute useCompute = new UseCompute();
        // useCompute.useCom(add, 4, 2);
        // useCompute.useCom(subtract, 4, 2);
        // useCompute.useCom(multiply, 4, 2);
        // useCompute.useCom(divide, 4, 2);

        var computes = new ArrayList<Compute>();
        computes.add(add);
        computes.add(subtract);
        computes.add(multiply);
        computes.add(divide);

        for (Compute c : computes) {
            int result = c.compute(4, 2);
            System.out.println("result: " + result);
        }

    }
}