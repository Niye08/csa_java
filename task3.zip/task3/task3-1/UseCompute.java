public class UseCompute {
    public void useCom(Compute com, int one, int two) {
        int result = com.compute(one, two);
        System.out.println("result: " + result);
    }
}