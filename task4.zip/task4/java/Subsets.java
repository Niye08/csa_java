import java.util.ArrayList;
import java.util.List;

public class Subsets {
    public List<List<Integer>> subsets(int[] nums) {
        List<List<Integer>> subsets = new ArrayList<>();
        backtrack(nums, 0, new ArrayList<>(), subsets);
        return subsets;
    }

    private void backtrack(int[] nums, int start, List<Integer> current, List<List<Integer>> subsets) {
        // 将当前子集添加到结果集中
        subsets.add(new ArrayList<>(current));

        // 遍历数组中的每个元素
        for (int i = start; i < nums.length; i++) {
            // 添加当前元素到当前子集中
            current.add(nums[i]);
            // 继续递归，探索下一个元素
            backtrack(nums, i + 1, current, subsets);
            // 回溯，移除最后一个添加的元素，以探索不包含该元素的其他子集
            current.remove(current.size() - 1);
        }
    }

    public static void main(String[] args) {
        int[] nums = { 1, 2, 3 };
        Subsets subsets = new Subsets();
        List<List<Integer>> result = subsets.subsets(nums);
        for (List<Integer> subset : result) {
            System.out.println(subset);
        }
    }
}