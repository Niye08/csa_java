import java.util.Scanner;

public class palouti {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入楼梯总数：");
        int number = scanner.nextInt();
        System.out.println(fun(number));
    }

    public static int fun(int n) {
        if (n == 1) {
            return 1;
        }
        if (n == 2) {
            return 2;
        } else {
            return fun(n - 1) + fun(n - 2);
        }
    }
}