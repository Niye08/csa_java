import java.util.Scanner;

public class reverse {
    public static void main(String[] args) {
        System.out.println("please input a number:");
        Scanner scanner = new Scanner(System.in);
        int number = scanner.nextInt();
        System.out.println(reverse(number));
    }

    public static int reverse(int x) {
        long reversed = 0;
        while (x != 0) {
            int digit = x % 10;
            x /= 10;
            if (reversed > Integer.MAX_VALUE / 10 || (reversed == Integer.MAX_VALUE / 10 && digit > 7))
                return 0;
            if (reversed < Integer.MIN_VALUE / 10 || (reversed == Integer.MIN_VALUE / 10 && digit < -8))
                return 0;
            reversed = reversed * 10 + digit;
        }
        return (int) reversed;
    }
}