import java.util.HashMap;

public class repeated {
    public static void main(String[] args) {
        HashMap<Integer, Integer> Map = new HashMap<>();
        int[] nums = { 1, 2, 3, 1 };
        boolean flag = true;
        for (int i = 0; i < nums.length; i++) {
            if (Map.containsKey(nums[i])) {
                flag = false;
                break;
            } else {
                Map.put(nums[i], null);
            }
        }
        System.out.println(flag);
    }
}