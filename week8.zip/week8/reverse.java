/**
 * Definition for singly-linked list.
 * struct ListNode {
 * int val;
 * ListNode *next;
 * ListNode() : val(0), next(nullptr) {}
 * ListNode(int x) : val(x), next(nullptr) {}
 * ListNode(int x, ListNode *next) : val(x), next(next) {}
 * };
 */
public class reverse {
    public ListNode reverseList(ListNode head) {
        if (head == null || head.next == null) {
            return head; // 如果链表为空或只有一个节点，直接返回原链表
        }

        // 创建一个哑节点作为新链表的头部
        ListNode dummy = new ListNode(0);
        dummy.next = head;

        // prev 用于保存前一个节点，curr 用于遍历原始链表
        ListNode prev = dummy;
        ListNode curr = head;

        // 遍历原始链表，反转指针方向
        while (curr != null) {
            ListNode nextTemp = curr.next; // 保存当前节点的下一个节点
            curr.next = prev; // 将当前节点的指针指向前一个节点
            prev = curr; // 更新前一个节点为当前节点
            curr = nextTemp; // 更新当前节点为下一个节点
        }

        return dummy.next; // 返回反转后的链表的头部
    }
}